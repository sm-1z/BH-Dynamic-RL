from setuptools import setup

setup(
    name="bh_dyn",
    version="0.0.1",
)
